<template>
  <q-page class="flex flex-center">
    <h5>Page Camera</h5>
  </q-page>
</template>

<script>
export default {
  name: "PageCamera"
};
</script>

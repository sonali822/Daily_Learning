<template>
  <q-page class="flex flex-center">
    <h5>Home Page</h5>
  </q-page>
</template>

<script>
export default {
  name: "PageHome"
};
</script>

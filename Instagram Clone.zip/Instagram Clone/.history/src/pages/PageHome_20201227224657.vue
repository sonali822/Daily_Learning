<template>
  <q-page class="constrain q-pa-md">
    <q-card class="card-post" flat bordered>
      <q-item>
        <q-item-section avatar>
          <q-avatar>
            <img src="https://cdn.quasar.dev/img/boy-avatar.png" />
          </q-avatar>
        </q-item-section>

        <q-item-section>
          <q-item-label class="text-bold">Sonali_Saxena</q-item-label>
          <q-item-label caption>
            San Francisco, United States
          </q-item-label>
        </q-item-section>
      </q-item>

      <q-separator />
      <q-img src="https://cdn.quasar.dev/img/parallax2.jpg" />
      <q-card-section>
        <div>Wow what a place !</div>
        <div class="text-subtitle2">Jan 22</div>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script>
export default {
  name: "PageHome"
};
</script>
<style lang="sass">
.crad-post
   .q-img
        min-height:200px
</style>

<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn
          flat
          dense
          round
          icon="menu"
          aria-label="Menu"
          @click="leftDrawerOpen = !leftDrawerOpen"
        />

        <q-toolbar-title>
          Quasar App
        </q-toolbar-title>

        <div>Quasar v{{ $q.version }}</div>
      </q-toolbar>
    </q-header>
    <q-footer class="bg-white" bordered>
      <q-tabs class="text-grey-10" active-color="primary">
        <q-route-tab to="/" name="home" icon="mail" label="Home" />
        <q-route-tab to="/camera" name="camera" icon="alarm" label="Camera" />
      </q-tabs> </q-footer
    >ss
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

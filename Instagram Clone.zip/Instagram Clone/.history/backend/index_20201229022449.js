/*
dependencies

*/

const express = require("express");

/*
config -express

*/
const app = express();
/*
endpoint

*/

app.get("/", (request, response) => {
  res.send("Hello World!");
});

/*
listen

*/
app.listen(3000);

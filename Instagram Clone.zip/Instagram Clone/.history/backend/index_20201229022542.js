/*
dependencies

*/

const express = require("express");

/*
config -express

*/
const app = express();
/*
endpoint

*/

app.get("/", (request, response) => {
  response.send("I Love Node so hard!");
});

/*
listen

*/
app.listen(3000);
